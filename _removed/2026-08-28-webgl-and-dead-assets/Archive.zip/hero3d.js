/* ==========================================================================
   KREATED V2 — HERO MARK, TRUE 3D

   Same approved concept as the Canvas 2D renderer it supersedes: the Kreated
   mark IS the artwork, nothing in front of it, nothing around it. Only the
   rendering model changes.

   What the 2D version could not do, and why that forced this rewrite:

     · no self-occlusion — separated pieces read as coplanar cutouts, because
       a 2D painter has no depth buffer
     · no true normals — side walls were shaded by SCREEN POSITION, so the
       concave notches where the arrow meets the stem were lit as if convex
     · no real perspective — near and far edges foreshortened equally
     · no environment response — every surface answered one synthetic key
     · stamped extrusion banded at 2x DPR

   All five are properties of the rendering model, not tuning parameters.

   Geometry comes from assets/img/kreated-mark.svg at runtime, so the approved
   file is the single source of truth — the 2D renderer had to carry a copy of
   the path data inline, which could drift from the asset.
   ========================================================================== */
import * as THREE from 'three';
import { SVGLoader } from 'three/SVGLoader';

export function mount(canvas, host, opts) {
  var reduce = !!opts.reduce;
  var fine = !!opts.fine;
  var tier = opts.tier || 'full';          /* 'full' | 'lite'                */

  var renderer, scene, camera, group, env, pmrem;
  var pieces = [];
  var raf = 0, last = 0, visible = true, disposed = false;
  var pointerX = null, pointerY = null, curX = 0, curY = 0;

  var DPR_CAP = tier === 'lite' ? 1.4 : 1.75;
  var FRAME_MS = tier === 'lite' ? 50 : 33;   /* the motion is slow; 20–30fps
                                                 is visually indistinguishable
                                                 here and much cheaper        */

  /* ---- the studio environment ------------------------------------------
     A polished metal mostly shows what is AROUND it, not what shines on it.
     Directional lights give a smooth metal only a pinpoint highlight, which
     is why an earlier pass here had a cobalt rim light at high intensity and
     no visible cobalt at all. So the cobalt lives in the environment: a dark
     room with one broad cool-white softbox and one cobalt strip, which the
     side walls and bevels then genuinely reflect.

     This is also why three's stock RoomEnvironment was dropped — it is a
     neutral white room, and the brand accent has to be in the reflection. */
  function buildEnvScene() {
    var s = new THREE.Scene();
    s.background = new THREE.Color(0x04060b);

    /* A flat emitter reflects as a flat block; a gradient reflects as falloff.
       Only the key needs it — the rest are small and hard on purpose. */
    function gradTex() {
      var c = document.createElement('canvas');
      c.width = 64; c.height = 64;
      var g = c.getContext('2d');
      var rg = g.createRadialGradient(32, 24, 2, 32, 32, 40);
      rg.addColorStop(0, '#ffffff');
      rg.addColorStop(0.55, '#8fa2bd');
      rg.addColorStop(1, '#000000');
      g.fillStyle = rg; g.fillRect(0, 0, 64, 64);
      var t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      return t;
    }

    function panel(hex, intensity, w, h, x, y, z, rx, ry, tex) {
      var mat = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide });
      mat.color = new THREE.Color(hex).multiplyScalar(intensity);
      if (tex) mat.map = tex;
      var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
      m.position.set(x, y, z);
      m.rotation.set(rx || 0, ry || 0, 0);
      s.add(m);
    }

    /* Five elements, down from eight. The three that were cut — a second
       cobalt bounce, a rear cool bounce and a graded ceiling — could not be
       told apart in side-by-side captures, and each one costs a face in every
       PMREM sample. Simplification, not compromise. */

    /* 1 · key softbox, upper-front-left, broad and graded */
    panel(0xffffff, 8.0, 13, 10, -8.0, 5.6, 5.0, 0, Math.PI * 0.28, gradTex());
    /* 2 · narrow hard white strip — the crisp bevel catches */
    panel(0xf6faff, 24.0, 0.55, 9, 2.4, 7.4, 3.4, Math.PI * 0.42, 0);
    /* 3 · cobalt strip, rear-right. Narrow: cobalt lands on edges, not faces */
    panel(0x0a47f0, 22.0, 1.5, 13, 8.6, -0.4, -1.4, 0, -Math.PI * 0.5);
    /* 4 · NEGATIVE FILL — a black flag killing reflection on the right. This
           is what makes the lit side read as lit; without it the object picks
           up light from everywhere and flattens. */
    panel(0x000000, 1.0, 16, 16, 7.4, 1.2, 5.4, 0, -Math.PI * 0.42);
    /* 5 · dark floor, grounds the reflection */
    panel(0x05070d, 1.0, 26, 26, 0, -10, 0, -Math.PI / 2, 0);
    return s;
  }

  var sweep = null;

  function buildLights() {
    /* Four lights, down from seven. The off-axis fill, the soft neutral fill
       and the second cool rim were each removable without a visible
       difference once the environment was doing the reflection work — they
       were adding shader cost and three more numbers to tune. */

    /* the key: frontal, so the small yaw swing cannot swing it into darkness */
    var key = new THREE.DirectionalLight(0xe8eef8, 2.9);
    key.position.set(-2.1, 2.5, 5.8);
    scene.add(key);

    /* the cobalt source, from the right, catching turn-away walls and bevels */
    var rim = new THREE.DirectionalLight(0x0a47f0, 4.4);
    rim.position.set(4.0, -1.2, 0.6);
    scene.add(rim);

    /* THE SIGNATURE SWEEP. One light, tracking slowly across the front on a
       long period, its colour running cool white -> cobalt as it travels so
       the brand accent is part of the event rather than a separate channel. */
    sweep = new THREE.DirectionalLight(0xf4f8ff, 0);
    sweep.position.set(0, 1.4, 5.0);
    scene.add(sweep);

    scene.add(new THREE.AmbientLight(0x212936, 0.75));
  }

  /* ---- material -------------------------------------------------------
     Dark graphite / black chrome. Metallic enough to answer the environment,
     rough enough never to look wet or liquid. */
  function faceMaterial() {
    return new THREE.MeshStandardMaterial({
      /* Graphite, and light enough to READ. Chasing a physically-correct
         near-black metal is what kept making this muddy; the page is already
         near-black, so the mark has to sit above it. Satin roughness holds
         the softbox as a soft gradient rather than a mirror. */
      color: 0x4a505c,
      metalness: 0.55,
      roughness: 0.42,
      envMapIntensity: 1.5
    });
  }
  function wallMaterial() {
    return new THREE.MeshStandardMaterial({
      /* Darker than the face, smoother, and biased navy-cobalt IN THE
         MATERIAL. Relying on a reflected strip to deliver the brand colour
         made cobalt a lottery that depended on angle; tinting the walls makes
         "dark graphite front, cobalt-lit depth" read at every frame. */
      color: 0x1b2c58,
      metalness: 0.88,
      roughness: 0.16,
      envMapIntensity: 2.6
    });
  }

  function buildGeometry(svgText) {
    var data = new SVGLoader().parse(svgText);
    var shapes = [];
    /* Each SVG path is one logical piece — the mark's own structure. Nothing
       is merged, split, redrawn or invented. */
    data.paths.forEach(function (p) {
      var s = SVGLoader.createShapes(p);
      if (s.length) shapes.push(s);
    });
    if (!shapes.length) throw new Error('no shapes in mark');

    var depth = 26;                    /* in SVG units (viewBox is 600)      */
    var bevel = 3.4;

    group = new THREE.Group();

    shapes.forEach(function (shapeSet, i) {
      var geo = new THREE.ExtrudeGeometry(shapeSet, {
        depth: depth,
        bevelEnabled: true,
        bevelThickness: bevel,
        bevelSize: bevel,
        bevelSegments: tier === 'lite' ? 2 : 4,
        curveSegments: tier === 'lite' ? 6 : 12
      });
      /* SVG runs Y-down, three runs Y-up. Doing that with a negative scale
         MIRRORS the object, and a mirror inverts the normals: every front
         face then lights as though it points away from the camera, which
         renders the whole mark near-black no matter how bright the studio is.
         So the flip is baked into the geometry and the winding is reversed to
         match, which keeps the transform a proper rotation. */
      geo.scale(1, -1, 1);
      var pos = geo.getAttribute('position');
      if (!geo.index) {
        var arr = pos.array, j, tmp;
        for (var v = 0; v < arr.length; v += 9) {      /* swap verts 0 and 2 */
          for (j = 0; j < 3; j++) {
            tmp = arr[v + j]; arr[v + j] = arr[v + 6 + j]; arr[v + 6 + j] = tmp;
          }
        }
        pos.needsUpdate = true;
      }
      geo.computeVertexNormals();
      var mesh = new THREE.Mesh(geo, [faceMaterial(), wallMaterial()]);
      group.add(mesh);
      pieces.push({ mesh: mesh, index: i });
    });

    /* centre on the real ink bounds and normalise scale */
    var box = new THREE.Box3().setFromObject(group);
    var size = new THREE.Vector3(); box.getSize(size);
    var mid = new THREE.Vector3(); box.getCenter(mid);
    group.children.forEach(function (m) {
      m.geometry.translate(-mid.x, -mid.y, -mid.z);
    });
    /* mobile frames tighter and larger — a branded closing moment, not a
       shrunken desktop canvas */
    var s = (tier === 'lite' ? 3.05 : 2.62) / Math.max(size.x, size.y);
    group.scale.multiplyScalar(s);
    scene.add(group);
  }

  /* ---- deconstruction --------------------------------------------------
     Same envelope as the approved 2D behaviour: flat, smooth open, hold,
     smooth settle, flat. Now the separation runs mostly along Z, so pieces
     genuinely pass in front of one another and the depth buffer does the
     occlusion that the 2D version had to fake and could not. */
  function sepEnv(p) {
    if (p < 0.40 || p > 0.92) return 0;
    var a;
    if (p < 0.57) { a = (p - 0.40) / 0.17; return a * a * (3 - 2 * a); }
    if (p < 0.70) return 1;
    a = 1 - (p - 0.70) / 0.22;
    return a * a * (3 - 2 * a);
  }

  var SEP_S = 19, YAW_S = 23, PITCH_S = 31, SWEEP_S = 29;

  /* the sweep envelope: flat for most of the period, one smooth rise and
     fall. Same shape language as the separation, deliberately out of phase
     with it (29 vs 19) so the two events never coincide. */
  function sweepEnv(p) {
    if (p < 0.10 || p > 0.62) return 0;
    var a = (p - 0.10) / 0.52;
    return Math.sin(a * Math.PI);
  }

  function pose(t, sepScale) {
    /* biased negative: that is the side facing the key, so the mark is well
       lit across the whole loop instead of only half of it */
    var yaw = -0.030 + Math.sin(t * Math.PI * 2 / YAW_S) * 0.052 + curX * 0.060;
    var pitch = Math.sin(t * Math.PI * 2 / PITCH_S) * 0.038 + curY * 0.045;
    group.rotation.y = yaw;
    group.rotation.x = pitch;

    /* THE SPECULAR EVENT — a real light crossing the object, not an overlay */
    if (sweep) {
      var sp = (t % SWEEP_S) / SWEEP_S;
      var e = sweepEnv(sp);
      sweep.intensity = e * 3.0;
      /* travels left to right across the front, dipping slightly as it goes */
      var ang = (-1.15 + sp * 2.3);
      sweep.position.set(Math.sin(ang) * 5.4, 1.9 - sp * 1.5, Math.cos(ang) * 5.0);
      /* and cools from white into cobalt as it crosses, so the brand accent
         is part of the one event instead of a second moving light */
      var m = Math.min(1, Math.max(0, (sp - 0.22) / 0.34));
      sweep.color.setRGB(1 - m * 0.86, 1 - m * 0.62, 1);
    }

    var sep = sepScale * sepEnv((t % SEP_S) / SEP_S);
    for (var i = 0; i < pieces.length; i++) {
      var m = pieces[i].mesh;
      /* alternate direction so pieces pull apart THROUGH each other in depth;
         the XY component stays tiny so the silhouette never breaks up */
      var dir = i % 2 === 0 ? 1 : -1;
      m.position.z = dir * sep * 0.46;   /* depth does the work */
      m.position.x = dir * sep * 0.052;
    }
  }

  function render() { renderer.render(scene, camera); }

  function loop(now) {
    if (disposed) return;
    raf = requestAnimationFrame(loop);
    if (!visible || document.hidden) return;
    if (now - last < FRAME_MS) return;
    last = now;
    if (fine && pointerX !== null) {
      curX += ((pointerX - 0.5) - curX) * 0.015;
      curY += ((pointerY - 0.5) - curY) * 0.015;
    } else {
      curX += (0 - curX) * 0.015; curY += (0 - curY) * 0.015;
    }
    pose(now / 1000, tier === 'lite' ? 0.72 : 1);
    render();
  }

  function resize() {
    var r = host.getBoundingClientRect();
    if (!r.width || !r.height) return;
    var dpr = Math.min(window.devicePixelRatio || 1, DPR_CAP);
    renderer.setPixelRatio(dpr);
    renderer.setSize(r.width, r.height, false);
    camera.aspect = r.width / r.height;
    camera.updateProjectionMatrix();
    if (reduce) render();
  }

  var rt = null;
  function onResize() { clearTimeout(rt); rt = setTimeout(resize, 160); }
  function onPointer(e) {
    var r = host.getBoundingClientRect();
    pointerX = (e.clientX - r.left) / r.width;
    pointerY = (e.clientY - r.top) / r.height;
  }
  function onLeave() { pointerX = null; pointerY = null; }

  /* ---- boot ------------------------------------------------------------ */
  return fetch('assets/img/kreated-mark.svg')
    .then(function (r) {
      if (!r.ok) throw new Error('mark fetch ' + r.status);
      return r.text();
    })
    .then(function (svgText) {
      renderer = new THREE.WebGLRenderer({
        canvas: canvas, antialias: true, alpha: true, powerPreference: 'low-power'
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.15;

      scene = new THREE.Scene();

      /* Restrained perspective. A narrow FOV keeps the mark close to front-on
         and avoids the wide-angle look that instantly reads as a 3D demo. */
      camera = new THREE.PerspectiveCamera(19, 1, 0.1, 100);
      camera.position.set(0, 0, 10.4);

      /* dark room environment, at low intensity — enough for the metal to
         have something to reflect, not enough to light the scene */
      pmrem = new THREE.PMREMGenerator(renderer);
      env = pmrem.fromScene(buildEnvScene(), 0.028).texture;
      scene.environment = env;

      buildLights();
      buildGeometry(svgText);
      resize();

      if ('IntersectionObserver' in window) {
        new IntersectionObserver(function (es) { visible = es[0].isIntersecting; },
          { rootMargin: '120px' }).observe(host);
      }
      window.addEventListener('resize', onResize, { passive: true });

      if (reduce) {
        /* a designed still: fully assembled, turned just enough to show the
           bevel and the side walls, cobalt on the rim */
        curX = 0; curY = 0;
        /* Chosen, not frozen. t = 4.6 catches the specular event on its rise
           — about a third of the way up — so the bevels and the upper faces
           are described without the mark flaring toward chrome, which the
           peak does. The second argument forces separation to exactly 0, so
           the silhouette is the approved mark, fully assembled. */
        pose(4.6, 0);
        render();
      } else {
        if (fine) {
          host.addEventListener('pointermove', onPointer, { passive: true });
          host.addEventListener('pointerleave', onLeave, { passive: true });
        }
        raf = requestAnimationFrame(loop);
      }

      return {
        dispose: function () {
          disposed = true;
          if (raf) cancelAnimationFrame(raf);
          clearTimeout(rt);
          window.removeEventListener('resize', onResize);
          host.removeEventListener('pointermove', onPointer);
          host.removeEventListener('pointerleave', onLeave);
          pieces.forEach(function (p) {
            p.mesh.geometry.dispose();
            p.mesh.material.forEach(function (m) { m.dispose(); });
          });
          if (env) env.dispose();
          if (pmrem) pmrem.dispose();
          renderer.dispose();
        }
      };
    });
}
