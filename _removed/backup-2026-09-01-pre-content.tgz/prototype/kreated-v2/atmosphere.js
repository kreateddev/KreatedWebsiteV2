/* ==========================================================================
   KREATED V2 — the scroll-driven light-to-blue transition
   Homepage only. Added 2026-08-31.

   WHAT IT DOES
   Publishes ONE number per frame — `--p`, 0 to 1 — onto the ROOT element as the
   visitor travels from the top of the Services room to the arrival of Work.
   Everything visible is CSS: the stylesheet interpolates the room's two theme
   token sets against it with color-mix, so this file never touches a colour, a
   gradient, or any style beyond that one number.

   It also publishes `--cross` — where the room's two themes meet — but that is
   GEOMETRY, written only on load and resize, never per frame. See measureCross.

   ⚠ IT IS SET ON <html>, NOT ON .room. The transition does not end at the
   room's floor: Work's own ground continues the same ramp down into the deep
   navy, so BOTH sections have to read the same progress value. Scoping it to
   .room is what previously made the room hand over to a solid block.

   PROGRESS RANGE
     start   the room's top edge reaches 88% of the viewport height
             (i.e. as Services is resolving, not before it is on screen)
     end     the top of Work reaches the BOTTOM of the viewport — i.e. the
             instant the Services/Work boundary first becomes visible
   ⚠ THAT END POINT IS LOAD-BEARING, not a taste call. The room's floor and
   Work's ramp are the same colour ONLY at --p = 1: the room composites its
   overlay over near-white, Work composites its ramp over near-black, so at any
   value below 1 the two sides of the join do not match and a step appears.
   Finishing the travel before the join can be seen guarantees it is only ever
   looked at when the two agree. 🚫 Do not push this end point later.
   The blue therefore arrives across the whole of Services and continues down
   through Work's opening — there is no single line where it changes.

   COST
   One passive scroll listener and one passive resize listener. The scroll
   handler does nothing but store window.scrollY and request a frame; all
   geometry is read once on load and re-read only on resize, so no frame ever
   forces a layout. The rAF callback writes one custom property, and only when
   the rounded value actually changed. There is no loop when nothing scrolls.

   ⚠ REDUCED MOTION — the listener is never attached and `--p` keeps the
   stylesheet's default, which is a deliberate, finished state rather than the
   start of an animation.
   ⚠ JS DISABLED — identical: the CSS default stands and the room renders
   complete. Nothing here is required for the page to be finished, only for it
   to respond.
   ========================================================================== */
(function () {
  'use strict';

  var room = document.querySelector('.room');
  if (!room) return;
  var work = document.getElementById('work');
  if (!work) return;
  var root = document.documentElement;

  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  if (mq && mq.matches) return;

  var start = 0, span = 1, last = -1, queued = false, y = 0;

  /* THE CROSSOVER.
     Where the room's two themes meet. It is the centre of the ink-free gap
     above the third service row — the middle of five — which is a real gap in
     the rendered page, not a percentage. Publishing it as a measurement is what
     lets the same rule be correct at 1440 and at 360, where that gap sits at
     58.1% and 52.3% of the room respectively.
     ⚠ Written on LOAD AND RESIZE ONLY, never per frame. It is geometry, not
     animation. The stylesheet carries measured percentage defaults so a no-JS
     visitor still gets the split in the right place. */
  function measureCross() {
    var rows = room.querySelectorAll('.svc__item');
    if (rows.length < 3) return;
    var roomTop = room.getBoundingClientRect().top + window.pageYOffset;
    var third = rows[2].getBoundingClientRect().top + window.pageYOffset;
    /* the gap straddles the row boundary: half of it is the previous row's
       bottom padding, half is this row's top padding. The boundary itself is
       therefore the gap's centre. */
    room.style.setProperty('--cross', Math.round(third - roomTop) + 'px');
  }

  /* the only place that reads layout */
  function measure() {
    var top = room.getBoundingClientRect().top + window.pageYOffset;
    var workTop = work.getBoundingClientRect().top + window.pageYOffset;
    var vh = window.innerHeight || document.documentElement.clientHeight;
    start = top - vh * 0.88;
    var end = workTop - vh * 0.98;
    span = Math.max(end - start, 1);
    measureCross();
  }

  function frame() {
    queued = false;
    var p = (y - start) / span;
    if (p < 0) { p = 0; } else if (p > 1) { p = 1; }
    /* two decimals is finer than the eye can read on an opacity ramp and it
       keeps this from writing a style on every single pixel of scroll */
    var v = Math.round(p * 100) / 100;
    if (v === last) return;
    last = v;
    root.style.setProperty('--p', v);
  }

  function onScroll() {
    y = window.pageYOffset;
    if (queued) return;
    queued = true;
    requestAnimationFrame(frame);
  }

  var rt = null;
  function onResize() {
    if (rt) { clearTimeout(rt); }
    rt = setTimeout(function () { measure(); last = -1; onScroll(); }, 150);
  }

  measure();
  y = window.pageYOffset;
  frame();

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onResize, { passive: true });
  /* late-loading images change the document height and therefore the range */
  window.addEventListener('load', function () { measure(); last = -1; onScroll(); });
}());
